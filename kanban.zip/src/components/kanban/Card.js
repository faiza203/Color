import React, { Component } from "react";
import { Link, BrowserRouter as Router } from "react-router-dom";

import {
  Card,
  CardText,
  CardBody,
  CardTitle,
  CardSubtitle,
  CardFooter,
} from "reactstrap";

const TicketCard = (props) => {
  const { content } = props;
  return (
    <div className="mb-2 mt-2 ticketCardWidth">
      <Card className="border-0 m-t-0 card " id="card2">
        <CardBody>
          <CardTitle tag="h4" className="title m-t-0">
            {content.content}
          </CardTitle>
          <CardSubtitle className="m-b-10 text-muted">
            Owner
            <div
              className="widget-img widget-img-xs rounded-circle bg-inverse mr-n2"
              style={{
                backgroundImage: "url(../assets/img/user/user-1.jpg)",
              }}
            ></div>
          </CardSubtitle>
          <CardSubtitle className="m-b-10 text-muted">
            Created on: 0000-00-00 00:00:00
          </CardSubtitle>
          <CardSubtitle className="m-b-10 text-muted">
            Deadline on: 0000-00-00 00:00:00
          </CardSubtitle>
          <CardSubtitle className="m-b-10 text-muted">
            Assigned To:
            <div className="d-flex">
              <div
                className="widget-img widget-img-xs rounded-circle bg-inverse mr-n2"
                style={{
                  backgroundImage: "url(../assets/img/user/user-1.jpg)",
                }}
              ></div>
              <div
                className="widget-img widget-img-xs rounded-circle bg-inverse mr-n2"
                style={{
                  backgroundImage: "url(../assets/img/user/user-2.jpg)",
                }}
              ></div>
              <div
                className="widget-img widget-img-xs rounded-circle bg-inverse mr-n2"
                style={{
                  backgroundImage: "url(../assets/img/user/user-3.jpg)",
                }}
              ></div>
              <div className="widget-icon widget-icon-xs rounded-circle bg-muted text-white f-s-10">
                +2
              </div>
            </div>
          </CardSubtitle>
          <CardSubtitle className="m-b-10 text-muted">
            Tickets-todo card adding
          </CardSubtitle>
          <CardText>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </CardText>
          <CardSubtitle className="m-b-10 text-muted d-flex">
            <p> Priority:</p>
            <div className="dropdown">
              <button
                className="btn btn-primary rounded pl-2 pt-1 pb-1 pr-2 border-0 ml-3 "
                type="button"
                id="dropdownMenuButton1"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Low
              </button>
              <ul
                className="dropdown-menu"
                aria-labelledby="dropdownMenuButton1"
              >
                <li>
                  <a className="dropdown-item" href="#">
                    Low
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Normal
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    High
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Urgent
                  </a>
                </li>
              </ul>
            </div>
          </CardSubtitle>
          <div>
            <CardSubtitle className="m-b-10 text-muted d-flex">
              <p> Priority:</p>
              <div className="dropdown">
                <button
                  className="btn btn-light rounded pl-2 pt-1 pb-1 pr-2 border-0 ml-3 "
                  type="button"
                  id="dropdownMenuButton1"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Status
                </button>
                <ul
                  className="dropdown-menu"
                  aria-labelledby="dropdownMenuButton1"
                >
                  <li>
                    <a className="dropdown-item" href="#">
                      Open
                    </a>
                  </li>
                  <li>
                    <a className="dropdown-item" href="#">
                      On Hold
                    </a>
                  </li>
                  <li>
                    <a className="dropdown-item" href="#">
                      Solved
                    </a>
                  </li>
                  <li>
                    <a className="dropdown-item" href="#">
                      Closed
                    </a>
                  </li>
                  <li>
                    <a className="dropdown-item" href="#">
                      Re Open
                    </a>
                  </li>
                </ul>
              </div>
            </CardSubtitle>
          </div>
        </CardBody>
        <CardFooter className="text-muted f-w-600">
          <Router>
            <Link
              to="/bootstrap-4"
              className="card-link"
              title="View details/profile"
            >
              <button
                type="button"
                className="btn btn-green btn-xs m-r-5 m-b-5"
              >
                <i className="far fa-eye"></i>
              </button>
            </Link>
            <Link to="/bootstrap-4" className="card-link" title="delete">
              <button type="button" className="btn btn-red btn-xs m-r-5 m-b-5">
                <i className="far fa-trash-alt"></i>
              </button>
            </Link>
            <Link to="/bootstrap-4" className="card-link" title="make comments">
              <button type="button" className="btn btn-lime btn-xs m-r-5 m-b-5">
                <i className="far fa-comments"></i>
              </button>
            </Link>
            <Link to="/bootstrap-4" className="card-link" title="share it">
              <button
                type="button"
                className="btn btn-purple btn-xs m-r-5 m-b-5"
              >
                <i className="ion-md-share"></i>
              </button>
            </Link>
            <Link to="/bootstrap-4" className="card-link" title="save as PDF">
              <button
                type="button"
                className="btn btn-orange btn-xs m-r-5 m-b-5"
              >
                <i className="far fa-file-pdf"></i>
              </button>
            </Link>
            <Link to="/bootstrap-4" className="card-link" title="print">
              <button
                type="button"
                className="btn btn-indigo btn-xs m-r-5 m-b-5"
              >
                <i className="fas fa-print"></i>
              </button>
            </Link>
            <Link to="/bootstrap-4" className="card-link" title="archive it">
              <button type="button" className="btn btn-gray btn-xs m-r-5 m-b-5">
                <i className="fas fa-archive"></i>
              </button>
            </Link>
          </Router>
        </CardFooter>
      </Card>
    </div>
  );
};

export default TicketCard;
