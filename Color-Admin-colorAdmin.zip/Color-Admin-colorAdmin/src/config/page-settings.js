import React from 'react';

export const PageSettings = React.createContext();